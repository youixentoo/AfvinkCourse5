/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opening;

import java.util.HashMap;

class UnknownAminoacidException extends Exception{
    String str1;
    
    UnknownAminoacidException(String str2) {
        str1 = str2;
    }

    @Override
    public String toString() {
        return ("UnknownAminoacidException Occurred: " + str1);
    }
}

/**
 *
 * @author thijs
 */
public class Translator {
    
    public String getThreeLetters(String Seq, boolean FullName) throws UnknownAminoacidException{
        String ThreeLetterCode = "";
        java.util.Map table = new HashMap(); //Codon table declaration
        // <editor-fold defaultstate="collapsed" desc="Table contents">
        table.put ("F", "Phe");
        table.put ("L", "Leu");
        table.put ("A", "Ala");
        table.put ("R", "Arg");
        table.put ("N", "Asn");
        table.put ("D", "Asp");
        table.put ("C", "Cys");
        table.put ("Q", "Gln");
        table.put ("E", "Glu");
        table.put ("G", "Gly");
        table.put ("H", "His");
        table.put ("I", "Ile");
        table.put ("K", "Lys");
        table.put ("M", "Met");
        table.put ("P", "Pro");
        table.put ("S", "Ser");
        table.put ("T", "Thr");
        table.put ("W", "Trp");
        table.put ("Y", "Tyr");
        table.put ("V", "Val");
        // </editor-fold>
        
        // <editor-fold defaultstate="collapsed" desc="Table contents">
        java.util.Map table2 = new HashMap();
        table2.put ("A", "Alenine");
        table2.put ("R", "Arginine");
        table2.put ("N", "Asparagine");
        table2.put ("C", "Cysteine");
        table2.put ("D", "Aspartate");
        table2.put ("Q", "Glutamine");
        table2.put ("E", "Glutamate");
        table2.put ("G", "Glycine");
        table2.put ("H", "Histidine");
        table2.put ("I", "Isoleucine");
        table2.put ("L", "Leucine");
        table2.put ("K", "Lysine");
        table2.put ("M", "Methionine");
        table2.put ("F", "Phenylalanine");
        table2.put ("P", "Proline");
        table2.put ("S", "Serine");
        table2.put ("T", "Threonine");
        table2.put ("W", "Thryptophan");
        table2.put ("V", "Valine");
        table2.put ("Y", "Tyrosine");
        // </editor-fold>
            
        for (String Letter:Seq.split("(?<=\\G.)")){
            try{
                if(FullName){
                    if((String)table2.get(Letter.toUpperCase()) != null){
                        ThreeLetterCode += (String)table2.get(Letter.toUpperCase());
                    }else{
                        ThreeLetterCode = null;
                        throw new UnknownAminoacidException("There is an unknown 1 letter aminoacid in this sequence");
                    }
                }else{
                    if((String)table.get(Letter.toUpperCase()) != null){
                        ThreeLetterCode += (String)table.get(Letter.toUpperCase());
                    }else{
                        ThreeLetterCode = null;
                        throw new UnknownAminoacidException("There is an unknown 1 letter aminoacid in this sequence");
                    }
                }
            }catch(Exception exc){
                throw new UnknownAminoacidException("There is an unknown 1 letter aminoacid in this sequence");
            }
        }
        return ThreeLetterCode;
    }
    
    public String getOneLetter(String Seq) throws UnknownAminoacidException{
        String OneLetterCode = "";
         java.util.Map table = new HashMap(); //Codon table declaration
            // <editor-fold defaultstate="collapsed" desc="Table contents">
            table.put ("Phe", "F");
            table.put ("Leu", "L");
            table.put ("Ala", "A");
            table.put ("Arg", "R");
            table.put ("Asn", "N");
            table.put ("Asp", "D");
            table.put ("Cys", "C");
            table.put ("Gln", "Q");
            table.put ("Glu", "E");
            table.put ("Gly", "G");
            table.put ("His", "H");
            table.put ("Ile", "I");
            table.put ("Lys", "K");
            table.put ("Met", "M");
            table.put ("Pro", "P");
            table.put ("Ser", "S");
            table.put ("Thr", "T");
            table.put ("Trp", "W");
            table.put ("Tyr", "Y");
            table.put ("Val", "V");
            // </editor-fold>
        
        
        
        for (String Abr:Seq.split("(?<=\\G...)")){
            try{
                if((String)table.get(Abr) != null){
                    OneLetterCode += (String)table.get(Abr);
                }else{
                    throw new UnknownAminoacidException("There is an unknown 3 letter aminoacid in this file");
                }
                
            }catch(Exception exc){
                throw new UnknownAminoacidException("There is an unknown 3 letter aminoacid in this file");
            }
        }
        
        return OneLetterCode;
    }


    
    
    
    
    
    
}

/*
 table.put ("PHE", "F");
            table.put ("LEU", "L");
            table.put ("ALA", "A");
            table.put ("ARG", "R");
            table.put ("ASN", "N");
            table.put ("ASP", "D");
            table.put ("CYS", "C");
            table.put ("GLN", "Q");
            table.put ("GLU", "E");
            table.put ("GLY", "G");
            table.put ("HIS", "H");
            table.put ("ILE", "I");
            table.put ("LYS", "K");
            table.put ("MET", "M");
            table.put ("PRO", "P");
            table.put ("SER", "S");
            table.put ("THR", "T");
            table.put ("TRP", "W");
            table.put ("TYR", "Y");
            table.put ("VAL", "V");
*/
