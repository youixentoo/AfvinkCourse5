/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package opening;

import java.io.IOException;
import java.util.HashMap;
/**
 *
 * @author thijs
 */
public class getProteins {

    public String Protein;
    public String arg1;  

    /**
     *
     * @param argument Input a DNA sequence (ATCG) in String and it will return the protein sequence in String.
     */
    public getProteins(String argument){
     
        //try{
            Protein = "";
            Integer Start_Codon;
            String value = argument;

            java.util.Map table = new HashMap(); //Codon table declaration
            // <editor-fold defaultstate="collapsed" desc="Table contents">
            table.put ("TTT", "F");
            table.put ("TTC", "F");
            table.put ("TTA", "L");
            table.put ("TTG", "L");
            table.put ("TCT", "S");
            table.put ("TCC", "S");
            table.put ("TCA", "S");
            table.put ("TCG", "S");
            table.put ("TAT", "Y");
            table.put ("TAC", "Y");
              //            TAA end
              //            TAG end
            table.put ("TGT", "C");
            table.put ("TGC", "C");
              //            TGA end
            table.put ("TGG", "W");
            table.put ("CTT", "L");
            table.put ("CTC", "L");
            table.put ("CTA", "L");
            table.put ("CTG", "L");
            table.put ("CCT", "P");
            table.put ("CCC", "P");
            table.put ("CCA", "P");
            table.put ("CCG", "P");
            table.put ("CAT", "H");
            table.put ("CAC", "H");
            table.put ("CAA", "Q");
            table.put ("CAG", "Q");
            table.put ("CGT", "R");
            table.put ("CGC", "R");
            table.put ("CGA", "R");
            table.put ("CGG", "R");
            table.put ("ATT", "I");
            table.put ("ATC", "I");
            table.put ("ATA", "I");
            table.put ("ATG", "M");
            table.put ("ACT", "T");
            table.put ("ACC", "T");
            table.put ("ACA", "T");
            table.put ("ACG", "T");
            table.put ("AAT", "N");
            table.put ("AAC", "N");
            table.put ("AAA", "K");
            table.put ("AAG", "K");
            table.put ("AGT", "S");
            table.put ("AGC", "S");
            table.put ("AGA", "R");
            table.put ("AGG", "R");
            table.put ("GTT", "V");
            table.put ("GTC", "V");
            table.put ("GTA", "V");
            table.put ("GTG", "V");
            table.put ("GCT", "A");
            table.put ("GCC", "A");
            table.put ("GCA", "A");
            table.put ("GCG", "A");
            table.put ("GAT", "D");
            table.put ("GAC", "D");
            table.put ("GAA", "E");
            table.put ("GAG", "E");
            table.put ("GGT", "G");
            table.put ("GGC", "G");
            table.put ("GGA", "G");
            table.put ("GGG", "G");
            // Source: http://gaggle.systemsbiology.net/svn/gaggle/gaggle/branches/original/org/systemsbiology/gaggle/geese/sequence/CodonTable.java
            // </editor-fold>


            Start_Codon = value.indexOf("ATG"); 
            /*
            This can give a StringIndexOutOfBoundsException Exception, which means there is no protein to be gotten. 
            And is therefore useless, and the header and value gets skipped if thrown
            */         
            String string_aug = value.substring(Start_Codon,value.length());
            String[] Splitted_codons = string_aug.split("(?<=\\G...)");
            //System.out.println(header+"\n"+java.util.Arrays.toString(Splitted_codons));


            for (String codon:Splitted_codons){ //Translation loop
                if(codon.equals("TAA")){
                    break;
                }else if(codon.equals("TAG")){
                    break;
                }else if(codon.equals("TGA")){
                    break;
                }else if(codon.length() < 3){//The way the string is splitted means there can be "codons" with a length less than 3, if this is true, there is no (full) protein.
                    Protein = "No full protein available";
                    break;
                }else{
                    Protein += (String)table.get(codon);
                }
            }
            
        final String GottenProtein = Protein;
        //}catch(StringIndexOutOfBoundsException Ex){
        //    return Ex.toString();
        //}
            
        
            
        
    }  
        
        
        
}       
   
    

